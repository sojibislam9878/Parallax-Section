<?php
/**
 * Plugin Name: Parallax Section - Block
 * Description: Makes background element scrolls slower than foreground content.
 * Version: 1.0.9
 * Author: bPlugins
 * Author URI: https://bplugins.com
 * License: GPLv3
 * License URI: https://www.gnu.org/licenses/gpl-3.0.txt
 * Text Domain: parallax-section
 */

// ABS PATH
if ( !defined( 'ABSPATH' ) ) { exit; }

// Constant
define( 'PSB_VERSION', isset( $_SERVER['HTTP_HOST'] ) && 'localhost' === $_SERVER['HTTP_HOST'] ? time() : '1.0.9' );
define( 'PSB_DIR_URL', plugin_dir_url( __FILE__ ) );
define( 'PSB_DIR_PATH', plugin_dir_path( __FILE__ ) );

// require_once 'inc/block.php';


if( !class_exists( 'PSBPlugin' ) ){
	class PSBPlugin{
		function __construct(){
			add_action( 'init', [ $this, 'onInit' ] );
		}

		function onInit(){
			register_block_type( __DIR__ . '/build',
				['render_callback'	=> [$this, 'render'] ]
			);
		}


		function render( $attributes, $content ){
			extract( $attributes );
	
			$className = $className ?? '';
			$blockClassName = "wp-block-psb-parallax $className align$align";
	
			// Styles
			$bgCSS = $this->getBackgroundCSS($background);
			$paddingCSS = $this->getSpaceCSS($padding);
	
			$mainSl = "#psbParallaxSection-$cId";
			$styles = "
				$mainSl{
					min-height: $minHeight;
				}
				$mainSl .psbParallaxSection{
					justify-content: $verticalAlign;
					text-align: $textAlign;
					min-height: $minHeight;
					padding: $paddingCSS;
				}
				$mainSl .psbParallaxImg{
					$bgCSS
				}
			";
			
			// Style disappearing problem
			global $allowedposttags;
			$allowed_html = wp_parse_args( ['style' => [], 'iframe' => [
				'allowfullscreen' => true,
				'allowpaymentrequest' => true,
				'height' => true,
				'loading' => true,
				'name' => true,
				'referrerpolicy' => true,
				'sandbox' => true,
				'src' => true,
				'srcdoc' => true,
				'width' => true,
				'aria-controls' => true,
				'aria-current' => true,
				'aria-describedby' => true,
				'aria-details' => true,
				'aria-expanded' => true,
				'aria-hidden' => true,
				'aria-label' => true,
				'aria-labelledby' => true,
				'aria-live' => true,
				'class' => true,
				'data-*' => true,
				'dir' => true,
				'hidden' => true,
				'id' => true,
				'lang' => true,
				'style' => true,
				'title' => true,
				'role' => true,
				'xml:lang' => true
			] ], $allowedposttags );
	
			ob_start(); ?>
			<div class='<?php echo esc_attr( $blockClassName ); ?>' id='psbParallaxSection-<?php echo esc_attr( $cId ) ?>'>
				<style>
					<?php echo esc_html( $styles ); ?>
				</style>
	
				<div class='psbParallaxImg' data-speed='<?php echo esc_attr( $speed ) ?>'></div>
	
				<div class='psbParallaxSection'>
					<?php echo wp_kses( $content, $allowed_html ); ?>
				</div>
			</div>
	
			<?php return ob_get_clean();
		} // Render
	
		function getBackgroundCSS( $bg, $isSolid = true, $isGradient = true, $isImage = true ) {
			extract( $bg );
			$type = $type ?? 'solid';
			$color = $color ?? '#000000b3';
			$gradient = $gradient ?? 'linear-gradient(135deg, #4527a4, #8344c5)';
			$image = $image ?? [];
			$position = $position ?? 'center center';
			$attachment = $attachment ?? 'initial';
			$repeat = $repeat ?? 'no-repeat';
			$size = $size ?? 'cover';
			$overlayColor = $overlayColor ?? '#000000b3';
		
			$gradientCSS = $isGradient ? "background: $gradient;" : '';
		
			$imgUrl = $image['url'] ?? '';
			$imageCSS = $isImage ? "background: url($imgUrl); background-color: $overlayColor; background-position: $position; background-size: $size; background-repeat: $repeat; background-attachment: $attachment; background-blend-mode: overlay;" : '';
		
			$solidCSS = $isSolid ? "background: $color;" : '';
		
			$styles = 'gradient' === $type ? $gradientCSS : ( 'image' === $type ? $imageCSS : $solidCSS );
		
			return $styles;
		}
	
		function getSpaceCSS( $space ) {
			extract( $space );
			$side = $side ?? 2;
			$vertical = $vertical ?? '0px';
			$horizontal = $horizontal ?? '0px';
			$top = $top ?? '0px';
			$right = $right ?? '0px';
			$bottom = $bottom ?? '0px';
			$left = $left ?? '0px';
		
			$styles = ( 2 === $side ) ? "$vertical $horizontal" : "$top $right $bottom $left";
	
			return $styles;
		}


	}
	new PSBPlugin();
}